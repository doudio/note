package com.stylefeng.guns.multi.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.stylefeng.guns.multi.entity.Test;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author fengshuonan
 * @since 2018-07-10
 */
public interface TestMapper extends BaseMapper<Test> {

}
