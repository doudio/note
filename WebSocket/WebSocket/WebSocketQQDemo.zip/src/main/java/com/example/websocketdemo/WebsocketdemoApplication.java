package com.example.websocketdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsocketdemoApplication.class, args);
	}
	
}
