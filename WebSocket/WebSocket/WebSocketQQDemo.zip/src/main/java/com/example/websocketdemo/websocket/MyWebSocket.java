package com.example.websocketdemo.websocket;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.springframework.stereotype.Component;

import com.example.websocketdemo.controller.WebSocketController;

@ServerEndpoint(value = "/WebSocketDemo")
@Component
public class MyWebSocket {

	private static final ConcurrentHashMap<String, MyWebSocket> webSocketMap = new ConcurrentHashMap<String, MyWebSocket>();
	
	public static ConcurrentHashMap<String, MyWebSocket> getWebsocketmap() {
		return webSocketMap;
	}

	private Session session;

	@OnOpen
	public void onOpen(Session session) {
		this.session = session;
		webSocketMap.put(session.getId(), this);
		System.out.println(String.format("QQ用户已上线, QQ号为(%s)", session.getId()));
	}

	@OnClose
	public void onClose() {
		webSocketMap.remove(session.getId());
		System.out.println(String.format("%s号QQ已下线", session.getId()));
	}

	@OnMessage
	public void onMessage(String message, Session session) throws IOException {
		if (!message.contains(",")) {
			this.sendMessage(String.format("系统温馨提示: %s,%s", session.getId(), "发送消息请规范(sessionID,message)"));
			return;
		}
		
		String[] split = message.split(",");
		
		MyWebSocket socket = webSocketMap.get(split[0]);
		if (socket == null) {
			this.sendMessage(String.format("系统温馨提示: %s, 用户[%s]不存在!", session.getId(), split[0]));
			return;
		}
		
		socket.sendMessage(String.format("%s, %s, message: %s", split[0], session.getId(), split[1]));
		this.sendMessage(String.format("消息发送成功: QQ>%s to QQ>[%s]", session.getId(), split[0]));
	}

	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println("application error!");
		WebSocketController.sendAllSocket("系统被你们聊崩溃了!!!");
	}

	public void sendMessage(String message) throws IOException {
		this.session.getBasicRemote().sendText(message);
	}

}