package com.example.websocketdemo.websocket;

import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;

@ServerEndpoint(value = "/websocket")
@Component
public class WebSocket {

	private static int onlineCount = 0;

	private static CopyOnWriteArraySet<WebSocket> webSocketSet = new CopyOnWriteArraySet<WebSocket>();

	public static CopyOnWriteArraySet<WebSocket> getWebSocketSet() {
		return webSocketSet;
	}
	
	private Session session;

	@OnOpen
	public void onOpen(Session session) {
		this.session = session;
		webSocketSet.add(this);
		addOnlineCount();
		System.out.println(String.format("add new connect at {count: %s}", getOnlineCount()));
		try {
			sendMessage("connect successfull");
		} catch (IOException e) {
			System.out.println(String.format("IO Error: {exception: %s}", e));
		}
	}

	@OnClose
	public void onClose() {
		webSocketSet.remove(this);
		subOnlineCount();
		System.out.println(String.format("connect close at {count: %s}", getOnlineCount()));
	}

	@OnMessage
	public void onMessage(String message, Session session) {
		System.out.println(String.format("Client Message at {message: %s}", message));

		// send all Socket
		for (WebSocket item : webSocketSet) {
			try {
				item.sendMessage(String.format("server at {message: %s}", message));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println("application error!");
		error.printStackTrace();
	}

	public void sendMessage(String message) throws IOException {
		// Send synchronized Message
		this.session.getBasicRemote().sendText(message);
		// Send asynchronization Message
		// this.session.getAsyncRemote().sendText(message);
	}

	public static void sendInfo(String message) throws IOException {
		for (WebSocket item : webSocketSet) {
			try {
				item.sendMessage(message);
			} catch (IOException e) {
				continue;
			}
		}
	}

	public static synchronized int getOnlineCount() {
		return onlineCount;
	}

	public static synchronized void addOnlineCount() {
		WebSocket.onlineCount++;
	}

	public static synchronized void subOnlineCount() {
		WebSocket.onlineCount--;
	}

}