package com.example.websocketdemo.controller;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.websocketdemo.websocket.MyWebSocket;

/**
 * 群发消息给所有 Socket
 */
@Controller
public class WebSocketController {

	@ResponseBody
	@GetMapping("sendAllSocket")
	public static String sendAllSocket(String context) {
		StringBuilder builder = new StringBuilder("SUCCESS");
		MyWebSocket.getWebsocketmap().entrySet().forEach(socket -> {
    		try {
				socket.getValue().sendMessage(String.format("%s,%s", socket.getKey(), context));
			} catch (IOException e) {
				String format = String.format("群发消息失败: %s", e);
				System.out.println(format);
				if ("SUCCESS".equals(builder.toString())) {
					builder.delete(0, builder.length());
				} else {
					builder.append(format);
				}
			}
    	});
		return builder.toString();
	}
	
}
